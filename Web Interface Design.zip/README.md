
  # Web Interface Design

  This is a code bundle for Web Interface Design. The original project is available at https://www.figma.com/design/auzNZOnrj2J9OdxvsepJ6g/Web-Interface-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  